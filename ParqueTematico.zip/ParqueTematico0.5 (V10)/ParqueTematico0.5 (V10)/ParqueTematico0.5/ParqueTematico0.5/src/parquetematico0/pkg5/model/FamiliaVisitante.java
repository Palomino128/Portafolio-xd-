package parquetematico0.pkg5.model;

import java.util.List;

/**
 * Representa a un visitante del tipo Familia.
 * Contiene información adicional como número de adultos y niños, y si hay discapacitados.
 */
public class FamiliaVisitante extends Visitante {

    private int numAdultos;
    private int numNinos;
    private boolean hayDiscapacitado;
    private List<Acompaniante> acompanantes;

    /**
     * Constructor completo.
     * @param nombre Nombre del grupo familiar
     * @param edad Edad del representante
     * @param numAdultos Número de adultos en el grupo
     * @param numNinos Número de niños en el grupo
     * @param hayDiscapacitado Indica si hay algún integrante discapacitado
     * @param acompanantes Lista de acompañantes adultos
     */
    public FamiliaVisitante(String nombre, int edad, int numAdultos, int numNinos, boolean hayDiscapacitado, List<Acompaniante> acompanantes) {
        super(nombre, edad, "Familia");
        this.numAdultos = numAdultos;
        this.numNinos = numNinos;
        this.hayDiscapacitado = hayDiscapacitado;
        this.acompanantes = acompanantes;
    }

    // =================== Getters y Setters ===================

    public int getNumAdultos() {
        return numAdultos;
    }

    public int getNumNinos() {
        return numNinos;
    }

    public boolean isHayDiscapacitado() {
        return hayDiscapacitado;
    }

    public List<Acompaniante> getAcompanantes() {
        return acompanantes;
    }

    public void setAcompanantes(List<Acompaniante> acompanantes) {
        this.acompanantes = acompanantes;
    }

    // =================== Lógica especial ===================

    /**
     * Verifica si se cumple con la proporción mínima de 1 adulto por cada 2 niños.
     * @return true si se cumple, false si no.
     */
    public boolean cumpleProporcionAcompanantes() {
        return numAdultos >= (numNinos / 2.0);
    }

    // =================== Prioridad ===================

    @Override
    public int getPrioridadBase() {
        return 2;
    }

    @Override
    public int getPrioridadAdicional() {
        int adicional = 0;
        if (hayDiscapacitado) adicional += 2;
        if (numNinos > 2) adicional += 1; // grupo familiar grande
        return adicional;
    }

    // =================== Representación ===================

    @Override
    public String toString() {
        return String.format("Grupo Familiar: %s | Adultos: %d | Niños: %d | ID: %s%s",
                nombre, numAdultos, numNinos, id,
                hayDiscapacitado ? " | Incluye discapacitado" : "");
    }

    public String toCSV() {
        return String.format("%s,%d,%d,%b,%s", nombre, numAdultos, numNinos, hayDiscapacitado, id);
    }

    public static String getCSVHeader() {
        return "Nombre,NumAdultos,NumNinos,HayDiscapacitado,ID";
    }
}

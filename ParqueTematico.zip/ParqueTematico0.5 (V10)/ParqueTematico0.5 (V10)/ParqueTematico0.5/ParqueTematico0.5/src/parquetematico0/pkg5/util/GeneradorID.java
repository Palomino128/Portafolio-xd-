package parquetematico0.pkg5.util;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Clase encargada de generar códigos únicos de identificación para los visitantes,
 * siguiendo las reglas del parque temático según tipo de ticket y categoría de edad.
 */
public class GeneradorID {

    private static final Set<String> idsGenerados = new HashSet<>(); // Para evitar duplicados
    private static final Random random = new Random();

    /**
     * Genera un ID único para un visitante.
     *
     * @param tipo Tipo de visitante: "normal", "vip", "familia", "discapacitado"
     * @param categoriaEdad Categoría de edad: "Bebé", "Niño", "Adolescente", "Adulto"
     * @param esGrupo true si viene en grupo (añade G y dígitos iguales), false si no
     * @return ID generado único (ej: ND123456, VB7777G)
     */
    public static String generarID(String tipo, String categoriaEdad, boolean esGrupo) {
        String prefijo = "";

        // Prefijo por tipo de ticket
        switch (tipo.toLowerCase()) {
            case "normal": prefijo = "N"; break;
            case "vip": prefijo = "V"; break;
            case "familia": prefijo = "F"; break;
            case "discapacitado": prefijo = "D"; break;
            default: prefijo = "X"; // tipo desconocido
        }

        // Prefijo por categoría de edad
        switch (categoriaEdad.toLowerCase()) {
            case "bebé": prefijo += "B"; break;
            case "niño": prefijo += "N"; break;
            case "adolescente": prefijo += "D"; break;
            case "adulto": prefijo += "A"; break;
            default: prefijo += "X"; // edad desconocida
        }

        String id;

        do {
            if (esGrupo) {
                // Generar 4 dígitos iguales para grupo (ej: 4444)
                int digito = random.nextInt(9) + 1;
                String grupoDigitos = String.valueOf(digito).repeat(4);
                id = prefijo + grupoDigitos + "G";
            } else {
                // Generar número de 6 dígitos aleatorios
                int numero = 100000 + random.nextInt(900000); // entre 100000 y 999999
                id = prefijo + numero;
            }
        } while (idsGenerados.contains(id)); // Asegurarse de que no se repita

        idsGenerados.add(id); // Guardar el nuevo ID generado
        return id;
    }
}

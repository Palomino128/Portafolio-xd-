package parquetematico0.pkg5.interfaces;

public interface ISujetoEstadisticas {
    void registrarObservador(IObservadorEstadisticas observador);
    void eliminarObservador(IObservadorEstadisticas observador);
    void notificarObservadores();
}
package parquetematico0.pkg5.strategy;

import parquetematico0.pkg5.interfaces.IVisitante;

/**
 * Interfaz del patrón Strategy para priorización de visitantes.
 */
public interface PriorizacionStrategy {
    int calcularPrioridad(IVisitante visitante);
}

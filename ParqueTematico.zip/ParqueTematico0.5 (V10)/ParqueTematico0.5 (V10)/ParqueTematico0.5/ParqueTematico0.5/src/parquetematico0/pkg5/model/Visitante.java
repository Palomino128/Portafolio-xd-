package parquetematico0.pkg5.model;

import parquetematico0.pkg5.interfaces.IVisitante;

/**
 * Clase base que representa a un visitante del parque temático.
 * Puede ser extendida por clases como VIPVisitante, FamiliaVisitante, DiscapacitadoVisitante, etc.
 */
public class Visitante implements IVisitante {

    // ==================== Atributos ====================

    protected String nombre;
    protected int edad;
    protected String tipoPase;     // Ej: Normal, VIP, Familia, Discapacidad
    protected String id;           // ID único generado automáticamente
    protected long tiempoLlegada;  // En milisegundos, se usa para calcular tiempo de espera

    // ==================== Constructor ====================

    public Visitante(String nombre, int edad, String tipoPase) {
        this.nombre = nombre;
        this.edad = edad;
        this.tipoPase = tipoPase;
    }

    // ==================== Getters y Setters ====================

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public String getTipoPase() {
        return tipoPase;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getTiempoLlegada() {
        return tiempoLlegada;
    }

    public void setTiempoLlegada(long tiempoLlegada) {
        this.tiempoLlegada = tiempoLlegada;
    }

    /**
     * Determina la categoría de edad según los rangos establecidos.
     * @return "Bebé", "Niño", "Adolescente", "Adulto"
     */
    public String getCategoriaEdad() {
        if (edad >= 1 && edad <= 5) return "Bebé";
        if (edad <= 14) return "Niño";
        if (edad <= 17) return "Adolescente";
        return "Adulto";
    }

    // ==================== Priorización ====================

    /**
     * Prioridad base para un visitante normal.
     * VIP o especiales deben sobrescribir este método.
     */
    @Override
    public int getPrioridadBase() {
        return 1;
    }

    /**
     * Prioridad adicional según características específicas (por defecto 0).
     */
    @Override
    public int getPrioridadAdicional() {
        return 0;
    }

    // ==================== Representación textual ====================

    @Override
    public String toString() {
        return String.format("Visitante: %s | Edad: %d (%s) | Tipo: %s | ID: %s",
                nombre, edad, getCategoriaEdad(), tipoPase, id);
    }

    /**
     * Devuelve los datos en formato CSV.
     */
    public String toCSV() {
        return String.format("%s,%d,%s,%s", nombre, edad, tipoPase, id);
    }

    /**
     * Encabezado para exportación en formato CSV.
     */
    public static String getCSVHeader() {
        return "Nombre,Edad,TipoPase,ID";
    }
}

package parquetematico0.pkg5.factory;

import java.util.ArrayList;
import java.util.List;
import parquetematico0.pkg5.model.*;
import parquetematico0.pkg5.util.GeneradorID; // Asegúrate de tener esta clase creada

/**
 * Fábrica para crear diferentes tipos de visitantes según los requisitos.
 */
public class VisitanteFactory {

    /**
     * Crea un visitante según el tipo y sus parámetros.
     *
     * @param tipo Tipo de visitante: normal, vip, familia, discapacitado
     * @param nombre Nombre del visitante
     * @param edad Edad del visitante
     * @param args Argumentos adicionales según el tipo
     * @return Objeto Visitante creado
     */
    public static Visitante crearVisitante(String tipo, String nombre, int edad, Object... args) {
        tipo = tipo.toLowerCase();
        Visitante visitante;

        try {
            switch (tipo) {
                case "vip":
                    // Verificar acompañante si es adolescente
                    if (edad >= 15 && edad <= 17) {
                        boolean tieneAcompanante = args.length > 0 && (boolean) args[0];
                        if (!tieneAcompanante) {
                            System.out.println("Los adolescentes VIP deben ingresar con un acompañante adulto.");
                            return null;
                        }
                    }
                    visitante = new VIPVisitante(nombre, edad);
                    break;

                case "familia":
                    if (args.length < 2) throw new IllegalArgumentException("Familia requiere adultos y niños.");
                    int adultos = (int) args[0];
                    int ninos = (int) args[1];
                    boolean tieneDiscapacidad = args.length > 2 ? (boolean) args[2] : false;
                    List<Acompaniante> acompanantes = args.length > 3 ? (List<Acompaniante>) args[3] : new ArrayList<>();

                    if (adultos < 1) {
                        System.out.println("Debe registrar al menos un adulto responsable en la familia.");
                        return null;
                    }

                    visitante = new FamiliaVisitante(nombre, edad, adultos, ninos, tieneDiscapacidad, acompanantes);
                    break;

                case "discapacitado":
                    if (args.length < 1) throw new IllegalArgumentException("Falta el tipo de discapacidad.");
                    String tipoDiscapacidad = (String) args[0];
                    boolean requiereAcompanante = args.length > 1 ? (boolean) args[1] : false;
                    String necesidades = args.length > 2 ? (String) args[2] : "Ninguna";

                    if (!requiereAcompanante) {
                        System.out.println("Los visitantes discapacitados deben ingresar con un acompañante.");
                        return null;
                    }

                    visitante = new DiscapacitadoVisitante(nombre, edad, tipoDiscapacidad, requiereAcompanante, necesidades);
                    break;

                case "normal":
                default:
                    Visitante normal = new Visitante(nombre, edad, "Normal");
                    if (normal.getEdad() < 18 && !normal.getCategoriaEdad().equals("Adulto")) {
                        System.out.println("AVISO: Menor de edad requiere acompañante");
                    }
                    return normal;
            }

            // Generar y asignar ID personalizado
            String categoriaEdad = visitante.getCategoriaEdad();
            String id = GeneradorID.generarID(tipo, categoriaEdad, false);
            visitante.setId(id);

            return visitante;

        } catch (Exception e) {
            System.err.println("Error al crear visitante: " + e.getMessage());
            return null;
        }
    }
}

package parquetematico0.pkg5.strategy;

import parquetematico0.pkg5.interfaces.IVisitante;
import parquetematico0.pkg5.model.FamiliaVisitante;

/**
 * Estrategia de prioridad para visitantes familiares.
 */
public class FamiliaPriorizacionStrategy implements PriorizacionStrategy {

    @Override
    public int calcularPrioridad(IVisitante visitante) {
        if (!(visitante instanceof FamiliaVisitante)) return 0;

        FamiliaVisitante familia = (FamiliaVisitante) visitante;
        int prioridad = 2;

        if (familia.getNumNinos() > 2) prioridad += 1;
        if (familia.isHayDiscapacitado()) prioridad += 2;

        return prioridad;
    }
}

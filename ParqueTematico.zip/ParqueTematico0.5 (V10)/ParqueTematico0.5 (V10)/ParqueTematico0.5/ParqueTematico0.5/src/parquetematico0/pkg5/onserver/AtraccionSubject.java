package parquetematico0.pkg5.onserver;

import java.util.ArrayList;
import java.util.List;
import parquetematico0.pkg5.interfaces.IObservadorEstadisticas;
import parquetematico0.pkg5.interfaces.ISujetoEstadisticas;

/**
 * Sujeto concreto para estadísticas de atracción
 */
public class AtraccionSubject implements ISujetoEstadisticas {
    private List<IObservadorEstadisticas> observadores;
    private int visitantesAtendidos;
    private double tiempoEsperaPromedio;
    
    public AtraccionSubject() {
        this.observadores = new ArrayList<>();
    }
    
    @Override
    public void registrarObservador(IObservadorEstadisticas observador) {
        observadores.add(observador);
    }
    
    @Override
    public void eliminarObservador(IObservadorEstadisticas observador) {
        observadores.remove(observador);
    }
    
    @Override
    public void notificarObservadores() {
        for (IObservadorEstadisticas observador : observadores) {
            observador.actualizar(visitantesAtendidos, tiempoEsperaPromedio);
        }
    }
    
    public void setEstadisticas(int visitantesAtendidos, double tiempoEsperaPromedio) {
        this.visitantesAtendidos = visitantesAtendidos;
        this.tiempoEsperaPromedio = tiempoEsperaPromedio;
        notificarObservadores();
    }
}
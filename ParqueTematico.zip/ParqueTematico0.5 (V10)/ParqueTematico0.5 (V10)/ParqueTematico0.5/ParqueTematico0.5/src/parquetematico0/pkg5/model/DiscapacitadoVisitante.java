package parquetematico0.pkg5.model;

import parquetematico0.pkg5.interfaces.IVisitante;

/**
 * Clase que representa a un visitante con discapacidad.
 * Extiende a Visitante y añade atributos específicos como tipo de discapacidad,
 * necesidad de acompañante y necesidades especiales.
 */
public class DiscapacitadoVisitante extends Visitante {

    private String tipoDiscapacidad;
    private boolean requiereAcompanante;
    private String necesidadesEspeciales;

    /**
     * Constructor completo
     */
    public DiscapacitadoVisitante(String nombre, int edad, String tipoDiscapacidad,
                                   boolean requiereAcompanante, String necesidadesEspeciales) {
        super(nombre, edad, "Discapacidad");
        this.tipoDiscapacidad = tipoDiscapacidad;
        this.requiereAcompanante = requiereAcompanante;
        this.necesidadesEspeciales = necesidadesEspeciales;
    }

    /**
     * Constructor simplificado (por defecto no requiere acompañante ni necesidades especiales).
     */
    public DiscapacitadoVisitante(String nombre, int edad, String tipoDiscapacidad) {
        this(nombre, edad, tipoDiscapacidad, false, "Ninguna");
    }

    // =================== GETTERS Y SETTERS ===================

    public String getTipoDiscapacidad() {
        return tipoDiscapacidad;
    }

    public void setTipoDiscapacidad(String tipoDiscapacidad) {
        this.tipoDiscapacidad = tipoDiscapacidad;
    }

    public boolean isRequiereAcompanante() {
        return requiereAcompanante;
    }

    public void setRequiereAcompanante(boolean requiereAcompanante) {
        this.requiereAcompanante = requiereAcompanante;
    }

    public String getNecesidadesEspeciales() {
        return necesidadesEspeciales;
    }

    public void setNecesidadesEspeciales(String necesidadesEspeciales) {
        this.necesidadesEspeciales = necesidadesEspeciales;
    }

    // =================== FUNCIONALIDAD EXTRA ===================

    /**
     * Verifica si la discapacidad impide el acceso a una atracción específica.
     */
    public boolean puedeAcceder(String atraccion) {
        String discapacidad = tipoDiscapacidad.toLowerCase();

        if (atraccion.equalsIgnoreCase("Rueda Gigante")) {
            return !(discapacidad.contains("cardíac") ||
                     discapacidad.contains("corazón") ||
                     discapacidad.contains("altura") ||
                     discapacidad.contains("vértigo"));
        }

        if (atraccion.equalsIgnoreCase("Montaña Rusa")) {
            return !(discapacidad.contains("cardíac") ||
                     discapacidad.contains("columna") ||
                     discapacidad.contains("espalda") ||
                     discapacidad.contains("embarazo") ||
                     discapacidad.contains("gestante"));
        }

        return true; // Por defecto, puede acceder
    }

    /**
     * Prioridad base alta para discapacitados.
     */
    @Override
    public int getPrioridadBase() {
        return 4;
    }

    /**
     * Prioridad adicional si requiere acompañante.
     */
    @Override
    public int getPrioridadAdicional() {
        return requiereAcompanante ? 1 : 0;
    }

    /**
     * Representación textual completa.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(" [Discapacidad: ").append(tipoDiscapacidad).append("]");
        if (requiereAcompanante) {
            sb.append(" (Requiere acompañante)");
        }
        if (!"Ninguna".equalsIgnoreCase(necesidadesEspeciales)) {
            sb.append(" [Necesidades: ").append(necesidadesEspeciales).append("]");
        }
        return sb.toString();
    }

    /**
     * Devuelve los datos en formato CSV.
     */
    public String toCSV() {
        return String.format("%s,%d,%s,%s,%b,%s",
                getNombre(),
                getEdad(),
                getTipoPase(),
                tipoDiscapacidad,
                requiereAcompanante,
                necesidadesEspeciales);
    }

    /**
     * Cabecera para exportación CSV.
     */
    public static String getCSVHeader() {
        return "Nombre,Edad,TipoPase,Discapacidad,RequiereAcompanante,NecesidadesEspeciales";
    }
}

// ILista.java
package parquetematico0.pkg5.interfaces;

/**
 * Interfaz para una lista genérica
 * @param <T> Tipo de elementos en la lista
 */
public interface ILista<T> {
    void agregar(T elemento);
    void insertar(int indice, T elemento);
    T obtener(int indice);
    T eliminar(int indice);
    boolean contiene(T elemento);
    int tamano();
    boolean estaVacia();
}
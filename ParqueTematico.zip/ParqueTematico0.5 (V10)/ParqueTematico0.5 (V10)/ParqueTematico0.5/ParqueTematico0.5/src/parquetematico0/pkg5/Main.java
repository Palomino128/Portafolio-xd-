package parquetematico0.pkg5;

import parquetematico0.pkg5.model.*;
import parquetematico0.pkg5.factory.VisitanteFactory;
import parquetematico0.pkg5.util.GeneradorID;
import parquetematico0.pkg5.concurrencia.HiloAtencion;

import java.util.*;

public class Main {
    static Scanner scanner = new Scanner(System.in);
    static List<Visitante> visitantes = new ArrayList<>();

    static Atraccion montanaRusa = new Atraccion("Montaña Rusa", 5, 4, 10, 20, 30);
    static Atraccion ruedaGigante = new Atraccion("Rueda Gigante", 6, 3, 8, 15, 25);
    static Atraccion laguna = new Atraccion("Laguna", 10, 3, 12, 25, 38);

    static HiloAtencion hiloMontana = new HiloAtencion(montanaRusa, 4000, 3);
    static HiloAtencion hiloRueda = new HiloAtencion(ruedaGigante, 5000, 3);
    static HiloAtencion hiloLaguna = new HiloAtencion(laguna, 3000, 3);

    public static void main(String[] args) {
        montanaRusa.abrir();
        ruedaGigante.abrir();
        laguna.abrir();

        hiloMontana.start();
        hiloRueda.start();
        hiloLaguna.start();

        int opcion;
        do {
            mostrarMenu();
            System.out.print("Seleccione una opción (1-5): ");
            while (!scanner.hasNextInt()) {
                System.out.print("Ingrese un número válido: ");
                scanner.next();
            }
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> registrarVisitante();
                case 2 -> agregarAatraccion();
                case 3 -> System.out.println("Atención automática activa (ver consola).");
                case 4 -> mostrarEstadisticas();
                case 5 -> cerrarParque();
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 5);
    }

    static void mostrarMenu() {
        System.out.println("\n========== MENÚ DEL PARQUE ==========\n");
        System.out.println("1. Registrar visitante (Normal, VIP, Familia, Discapacitado)");
        System.out.println("2. Agregar visitante a una atracción (Montaña Rusa, Rueda Gigante, Laguna)");
        System.out.println("3. Ver estado de atención automática");
        System.out.println("4. Mostrar estadísticas");
        System.out.println("5. Salir\n");
    }

    static void registrarVisitante() {
        System.out.print("Nombre del visitante: ");
        String nombre = scanner.nextLine();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Tipo de pase (normal / vip / familia / discapacitado): ");
        String tipo = scanner.nextLine().toLowerCase();

        Visitante visitante = null;

        switch (tipo) {
            case "vip" -> visitante = VisitanteFactory.crearVisitante("vip", nombre, edad);
            case "familia" -> {
                System.out.print("Número de adultos: ");
                int adultos = scanner.nextInt();
                System.out.print("Número de niños: ");
                int ninos = scanner.nextInt();
                scanner.nextLine();
                visitante = VisitanteFactory.crearVisitante("familia", nombre, edad, adultos, ninos);
            }
            case "discapacitado" -> {
                System.out.print("Tipo de discapacidad: ");
                String tipoDis = scanner.nextLine();
                System.out.print("¿Requiere acompañante? (true/false): ");
                boolean requiere = scanner.nextBoolean();
                scanner.nextLine();
                visitante = VisitanteFactory.crearVisitante("discapacitado", nombre, edad, tipoDis, requiere);
            }
            default -> visitante = VisitanteFactory.crearVisitante("normal", nombre, edad);
        }

        if (visitante != null) {
            visitantes.add(visitante);
            System.out.println("Visitante registrado: " + visitante);
        } else {
            System.out.println("Error al crear visitante.");
        }
    }

    static void agregarAatraccion() {
        if (visitantes.isEmpty()) {
            System.out.println("No hay visitantes registrados.");
            return;
        }

        mostrarVisitantes();

        System.out.print("Seleccione el número del visitante: ");
        int idx = scanner.nextInt() - 1;
        scanner.nextLine();

        if (idx < 0 || idx >= visitantes.size()) {
            System.out.println("Índice inválido.");
            return;
        }

        Visitante v = visitantes.get(idx);

        System.out.println("Seleccione atracción:");
        System.out.println("1. Montaña Rusa");
        System.out.println("2. Rueda Gigante");
        System.out.println("3. Laguna");
        System.out.print("Opción: ");
        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1 -> montanaRusa.agregarVisitante(v);
            case 2 -> ruedaGigante.agregarVisitante(v);
            case 3 -> laguna.agregarVisitante(v);
            default -> System.out.println("Opción inválida.");
        }
    }

    static void mostrarEstadisticas() {
        System.out.println("\n--- ESTADÍSTICAS DE COLA ---");
        mostrarTamanioCola(montanaRusa);
        mostrarTamanioCola(ruedaGigante);
        mostrarTamanioCola(laguna);
    }

    static void mostrarTamanioCola(Atraccion atraccion) {
        System.out.printf("Cola en %s: %d visitantes%n", atraccion.getNombre(), atraccion.getTamanioCola());
    }

    static void mostrarVisitantes() {
        System.out.println("Lista de visitantes:");
        for (int i = 0; i < visitantes.size(); i++) {
            System.out.printf("%d. %s%n", i + 1, visitantes.get(i).toString());
        }
    }

    static void cerrarParque() {
        System.out.println("Cerrando el parque y deteniendo hilos...");
        hiloMontana.detener();
        hiloRueda.detener();
        hiloLaguna.detener();
        System.out.println("¡Hasta pronto!");
    }
}

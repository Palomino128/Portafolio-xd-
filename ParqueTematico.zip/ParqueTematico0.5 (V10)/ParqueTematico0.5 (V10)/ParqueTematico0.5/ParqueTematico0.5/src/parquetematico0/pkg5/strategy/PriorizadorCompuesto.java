package parquetematico0.pkg5.strategy;

import parquetematico0.pkg5.interfaces.IVisitante;
import java.util.ArrayList;
import java.util.List;

/**
 * Componente que combina múltiples estrategias de priorización
 */
public class PriorizadorCompuesto implements PriorizacionStrategy {
    private List<PriorizacionStrategy> estrategias;
    
    public PriorizadorCompuesto() {
        this.estrategias = new ArrayList<>();
        // Estrategias por defecto
        this.estrategias.add(new VIPPriorizacionStrategy());
        this.estrategias.add(new FamiliaPriorizacionStrategy());
        this.estrategias.add(new DiscapacidadPriorizacionStrategy());
    }
    
    /**
     * Agrega una nueva estrategia de priorización
     * @param estrategia Estrategia a agregar
     */
    public void agregarEstrategia(PriorizacionStrategy estrategia) {
        this.estrategias.add(estrategia);
    }
    
    @Override
    public int calcularPrioridad(IVisitante visitante) {
        int prioridadTotal = 0;
        
        // Aplicar todas las estrategias registradas
        for (PriorizacionStrategy estrategia : estrategias) {
            prioridadTotal += estrategia.calcularPrioridad(visitante);
        }
        
        return prioridadTotal;
    }
}

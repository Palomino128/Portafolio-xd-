package parquetematico0.pkg5.interfaces;

/**
 * Interfaz que define el comportamiento esencial de una atracción del parque.
 */
public interface IAtraccion {

    /**
     * Abre la atracción (estado abierta).
     */
    void abrir();

    /**
     * Cierra la atracción (estado cerrada).
     */
    void cerrar();

    /**
     * Indica si la atracción está actualmente abierta.
     * @return true si está abierta, false si está cerrada.
     */
    boolean estaAbierta();

    /**
     * Devuelve el nombre de la atracción.
     * @return nombre como String
     */
    String getNombre();

    /**
     * Devuelve la capacidad máxima por turno.
     * @return capacidad como entero
     */
    int getCapacidad();

    /**
     * Devuelve el tiempo de uso por turno en minutos.
     * @return duración como entero
     */
    int getTiempoUso();
}

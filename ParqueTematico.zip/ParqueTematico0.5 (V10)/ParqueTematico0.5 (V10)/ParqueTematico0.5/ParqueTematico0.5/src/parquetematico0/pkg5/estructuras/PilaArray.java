package parquetematico0.pkg5.estructuras;

import parquetematico0.pkg5.interfaces.IPila;

/**
 * Implementación de una pila usando un array genérico
 * @param <T> Tipo de elementos en la pila
 */
public class PilaArray<T> implements IPila<T> {
    private static final int CAPACIDAD_INICIAL = 10;
    private Object[] elementos;
    private int tope;
    
    public PilaArray() {
        elementos = new Object[CAPACIDAD_INICIAL];
        tope = -1;
    }
    
    @Override
    public void apilar(T elemento) {
        if (tope == elementos.length - 1) {
            ampliarCapacidad();
        }
        elementos[++tope] = elemento;
    }
    
    @Override
    public T desapilar() {
        if (estaVacia()) {
            throw new IllegalStateException("Pila vacía");
        }
        @SuppressWarnings("unchecked")
        T elemento = (T) elementos[tope];
        elementos[tope--] = null;
        return elemento;
    }
    
    @Override
    public T cima() {
        if (estaVacia()) {
            throw new IllegalStateException("Pila vacía");
        }
        @SuppressWarnings("unchecked")
        T elemento = (T) elementos[tope];
        return elemento;
    }
    
    @Override
    public boolean estaVacia() {
        return tope == -1;
    }
    
    @Override
    public int tamano() {
        return tope + 1;
    }
    
    private void ampliarCapacidad() {
        Object[] nuevoArray = new Object[elementos.length * 2];
        System.arraycopy(elementos, 0, nuevoArray, 0, elementos.length);
        elementos = nuevoArray;
    }
}
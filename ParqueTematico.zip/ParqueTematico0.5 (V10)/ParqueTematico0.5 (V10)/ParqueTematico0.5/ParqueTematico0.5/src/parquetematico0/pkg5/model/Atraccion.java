package parquetematico0.pkg5.model;

import parquetematico0.pkg5.estructuras.ColaPrioridad;
import parquetematico0.pkg5.interfaces.IAtraccion;
import parquetematico0.pkg5.onserver.AtraccionSubject;
import parquetematico0.pkg5.onserver.EstadisticasObserver;
import parquetematico0.pkg5.strategy.*;

/**
 * Clase que representa una atracción del parque.
 * Gestiona cola de visitantes, acceso, prioridad y estadísticas.
 */
public class Atraccion implements IAtraccion {

    // ==================== Atributos ====================
    private String nombre;
    private int capacidad;
    private int tiempoUso;
    private boolean abierta;

    private ColaPrioridad<Visitante> cola;
    private double precioNinos;
    private double precioAdolescentes;
    private double precioAdultos;

    private AtraccionSubject subject;
    private int visitantesAtendidos;
    private long tiempoEsperaAcumulado;

    private PriorizacionStrategy[] estrategiasPriorizacion;

    // ==================== Constructor ====================
    public Atraccion(String nombre, int capacidad, int tiempoUso,
                     double precioNinos, double precioAdolescentes, double precioAdultos) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.tiempoUso = tiempoUso;
        this.abierta = false;

        this.precioNinos = precioNinos;
        this.precioAdolescentes = precioAdolescentes;
        this.precioAdultos = precioAdultos;

        this.cola = new ColaPrioridad<>();
        this.subject = new AtraccionSubject();
        this.subject.registrarObservador(new EstadisticasObserver(nombre));

        this.visitantesAtendidos = 0;
        this.tiempoEsperaAcumulado = 0;

        this.estrategiasPriorizacion = new PriorizacionStrategy[]{
            new VIPPriorizacionStrategy(),
            new FamiliaPriorizacionStrategy(),
            new DiscapacidadPriorizacionStrategy(),
            new EdadPriorizacionStrategy()
        };
    }

    // ==================== Métodos IAtraccion ====================
    @Override
    public void abrir() {
        abierta = true;
        System.out.println(nombre + " ha sido abierta.");
    }

    @Override
    public void cerrar() {
        abierta = false;
        System.out.println(nombre + " ha sido cerrada.");
    }

    @Override
    public boolean estaAbierta() {
        return abierta;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getCapacidad() {
        return capacidad;
    }

    @Override
    public int getTiempoUso() {
        return tiempoUso;
    }

    public int getTamanioCola() {
        return cola.tamano();
    }

    // ==================== Gestión de Visitantes ====================
    public void agregarVisitante(Visitante visitante) {
        if (!abierta) {
            System.out.println("La atracción está cerrada.");
            return;
        }

        if (!validarAcceso(visitante)) {
            System.out.println("ACCESO DENEGADO a " + visitante.getNombre());
            return;
        }

        visitante.setTiempoLlegada(System.currentTimeMillis());

        int prioridad = calcularPrioridad(visitante);
        cola.encolar(visitante, prioridad);

        System.out.println(visitante.getNombre() + " ingresó a la cola de " + nombre + " (Prioridad: " + prioridad + ")");
    }

    public Visitante atenderVisitante() {
        if (cola.estaVacia()) {
            System.out.println("No hay visitantes en cola.");
            return null;
        }

        Visitante visitante = cola.desencolar();
        registrarAtendido(visitante);
        return visitante;
    }

    private void registrarAtendido(Visitante visitante) {
        long espera = System.currentTimeMillis() - visitante.getTiempoLlegada();
        tiempoEsperaAcumulado += espera;
        visitantesAtendidos++;

        double promedio = tiempoEsperaAcumulado / 1000.0 / visitantesAtendidos;
        subject.setEstadisticas(visitantesAtendidos, promedio);

        System.out.printf("Atendiendo a %s en %s (Esperó %.2f s)%n",
                visitante.getNombre(), nombre, espera / 1000.0);
    }

    // ==================== Validaciones por Atracción ====================
    private boolean validarAcceso(Visitante v) {
        String nombreLower = nombre.toLowerCase();

        if (nombreLower.contains("montaña")) {
            return validarParaMontanaRusa(v);
        }

        if (nombreLower.contains("rueda")) {
            return validarParaRuedaGigante(v);
        }

        if (nombreLower.contains("laguna")) {
            return true; // Sin restricciones
        }

        return true; // otras atracciones
    }

    private boolean validarParaMontanaRusa(Visitante v) {
        if (v.getEdad() < 12) {
            System.out.println("Menores de 12 años no pueden ingresar a la Montaña Rusa.");
            return false;
        }

        if (v instanceof DiscapacitadoVisitante) {
            String d = ((DiscapacitadoVisitante) v).getTipoDiscapacidad().toLowerCase();
            if (d.contains("cardíac") || d.contains("columna")) {
                System.out.println("Restricción médica: " + d);
                return false;
            }
        }

        return true;
    }

    private boolean validarParaRuedaGigante(Visitante v) {
        if (v.getEdad() < 6 && !(v instanceof FamiliaVisitante)) {
            System.out.println("Menores de 6 años solo con acompañante.");
            return false;
        }

        if (v instanceof DiscapacitadoVisitante) {
            String d = ((DiscapacitadoVisitante) v).getTipoDiscapacidad().toLowerCase();
            if (d.contains("cardíac") || d.contains("altura")) {
                System.out.println("Restricción médica: " + d);
                return false;
            }
        }

        return true;
    }

    // ==================== Priorización ====================
    private int calcularPrioridad(Visitante v) {
        int prioridad = 0;
        for (PriorizacionStrategy estrategia : estrategiasPriorizacion) {
            prioridad += estrategia.calcularPrioridad(v);
        }
        return prioridad;
    }

    // ==================== Cálculo de Precio con Descuentos ====================
    public double calcularPrecio(Visitante v) {
        String nombreLower = nombre.toLowerCase();
        double base;

        if (v.getEdad() < 6) return 0;
        if (v.getEdad() <= 14) base = precioNinos;
        else if (v.getEdad() <= 17) base = precioAdolescentes;
        else base = precioAdultos;

        // Descuentos especiales en Laguna
        if (nombreLower.contains("laguna")) {
            if (v instanceof DiscapacitadoVisitante) {
                DiscapacitadoVisitante d = (DiscapacitadoVisitante) v;
                if (d.isRequiereAcompanante()) {
                    System.out.println("Acompañante entra GRATIS.");
                    return 0;
                }
                return base * 0.6; // 40% descuento
            }

            if (v instanceof FamiliaVisitante) {
                FamiliaVisitante f = (FamiliaVisitante) v;
                if (f.getNumNinos() > 2) {
                    return base * 0.8; // 20% descuento por grupo grande
                }
            }
        }

        return base;
    }

    public double getPrecioNinos() {
        return precioNinos;
    }

    public double getPrecioAdolescentes() {
        return precioAdolescentes;
    }

    public double getPrecioAdultos() {
        return precioAdultos;
    }
}

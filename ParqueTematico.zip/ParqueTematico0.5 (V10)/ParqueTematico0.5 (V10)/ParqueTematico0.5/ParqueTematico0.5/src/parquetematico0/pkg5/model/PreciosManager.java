package parquetematico0.pkg5.model;

/**
 * Clase para calcular el precio de entrada de un visitante según su tipo de pase y edad.
 */
public class PreciosManager {

    public static double calcularPrecioEntrada(Visitante visitante) {
        switch (visitante.getTipoPase()) {
            case "VIP":
                return calcularPrecioVIP(visitante);
            case "Familia":
                return calcularPrecioFamilia(visitante);
            case "Discapacidad":
                return calcularPrecioDiscapacitado(visitante);
            default:
                return calcularPrecioNormal(visitante);
        }
    }

    private static double calcularPrecioNormal(Visitante v) {
        String categoria = obtenerCategoriaEdad(v.getEdad());
        switch (categoria) {
            case "Niño": return 10.0;
            case "Adolescente": return 20.0;
            case "Adulto": return 30.0;
            default: return 0.0;
        }
    }

    private static double calcularPrecioVIP(Visitante v) {
        String categoria = obtenerCategoriaEdad(v.getEdad());
        switch (categoria) {
            case "Niño": return 20.0;
            case "Adolescente": return 30.0;
            case "Adulto": return 40.0;
            default: return 0.0;
        }
    }

    private static double calcularPrecioFamilia(Visitante v) {
        String categoria = obtenerCategoriaEdad(v.getEdad());
        switch (categoria) {
            case "Niño": return 6.0;
            case "Adolescente": return 12.0;
            case "Adulto": return 18.0;
            default: return 0.0;
        }
    }

    private static double calcularPrecioDiscapacitado(Visitante v) {
        String categoria = obtenerCategoriaEdad(v.getEdad());
        switch (categoria) {
            case "Niño": return 5.0;
            case "Adolescente": return 8.0;
            case "Adulto": return 10.0;
            default: return 0.0;
        }
    }

    // Método auxiliar para categorizar por edad
    private static String obtenerCategoriaEdad(int edad) {
        if (edad < 5) return "Bebé";
        if (edad < 12) return "Niño";
        if (edad < 18) return "Adolescente";
        return "Adulto";
    }
}

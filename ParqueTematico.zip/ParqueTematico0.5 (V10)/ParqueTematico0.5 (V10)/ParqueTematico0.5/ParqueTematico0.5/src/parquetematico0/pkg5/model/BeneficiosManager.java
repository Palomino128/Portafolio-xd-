package parquetematico0.pkg5.model;

/**
 * Clase que administra y aplica los beneficios según el tipo de pase del visitante.
 */
public class BeneficiosManager {

    // Método principal para aplicar beneficios
    public static void aplicarBeneficios(Visitante visitante) {
        switch (visitante.getTipoPase()) {
            case "VIP":
                aplicarBeneficiosVIP(visitante);
                break;
            case "Familia":
                aplicarBeneficiosFamilia(visitante);
                break;
            case "Discapacidad":
                aplicarBeneficiosDiscapacitado(visitante);
                break;
            default:
                aplicarBeneficiosNormal(visitante);
        }
    }

    // Beneficios para visitantes VIP
    private static void aplicarBeneficiosVIP(Visitante v) {
        System.out.println("BENEFICIOS VIP:");
        System.out.println("- Bebidas ilimitadas de 500ml");
        System.out.println("- Algodones de azúcar gratis");
        System.out.println("- 50% de descuento en todos los juegos");
    }

    // Beneficios para visitantes con pase familiar
    private static void aplicarBeneficiosFamilia(Visitante v) {
        System.out.println("BENEFICIOS FAMILIA:");
        System.out.println("- 20% de descuento en Montaña Rusa");
        System.out.println("- 10% de descuento en alimentos para el grupo familiar");
    }

    // Beneficios para visitantes con discapacidad
    private static void aplicarBeneficiosDiscapacitado(Visitante v) {
        System.out.println("BENEFICIOS DISCAPACIDAD:");
        System.out.println("- Acceso preferencial sin hacer fila");
        System.out.println("- 30% de descuento en entradas");
        System.out.println("- Acceso gratuito para un acompañante");
    }

    // Beneficios por defecto para visitantes normales
    private static void aplicarBeneficiosNormal(Visitante v) {
        System.out.println("BENEFICIOS NORMAL:");
        System.out.println("- Acceso a todas las atracciones con tarifa estándar");
    }
}

package parquetematico0.pkg5.interfaces;
// IPila.java
/**
 * Interfaz para una pila genérica
 * @param <T> Tipo de elementos en la pila
 */
public interface IPila<T> {
    void apilar(T elemento);
    T desapilar();
    T cima();
    boolean estaVacia();
    int tamano();
}
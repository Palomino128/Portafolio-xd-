// VIPPriorizacionStrategy.java
package parquetematico0.pkg5.strategy;

import parquetematico0.pkg5.interfaces.IVisitante;

public class VIPPriorizacionStrategy implements PriorizacionStrategy {
    @Override
    public int calcularPrioridad(IVisitante visitante) {
        return visitante.getTipoPase().equalsIgnoreCase("VIP") ? 3 : 0;
    }
}


package parquetematico0.pkg5.model;

/**
 * Clase básica que representa a un acompañante.
 */
public class Acompaniante {

    private String nombre;
    private int edad;

    /**
     * Constructor principal.
     */
    public Acompaniante(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    // ============ Getters y Setters ============

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    // ============ Representación textual ============

    @Override
    public String toString() {
        return String.format("Acompañante: %s | Edad: %d", nombre, edad);
    }

    /**
     * CSV simple para exportación.
     */
    public String toCSV() {
        return String.format("%s,%d", nombre, edad);
    }

    public static String getCSVHeader() {
        return "Nombre,Edad";
    }
}

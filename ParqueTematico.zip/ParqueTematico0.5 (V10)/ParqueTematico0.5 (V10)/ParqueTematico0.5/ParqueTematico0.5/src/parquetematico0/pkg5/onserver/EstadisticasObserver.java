package parquetematico0.pkg5.onserver;

import parquetematico0.pkg5.interfaces.IObservadorEstadisticas;

/**
 * Observador concreto para estadísticas
 */
public class EstadisticasObserver implements IObservadorEstadisticas {
    private String nombreAtraccion;
    
    public EstadisticasObserver(String nombreAtraccion) {
        this.nombreAtraccion = nombreAtraccion;
    }
    
    @Override
    public void actualizar(int visitantesAtendidos, double tiempoEsperaPromedio) {
        System.out.println("Estadísticas actualizadas para " + nombreAtraccion + ":");
        System.out.println(" - Visitantes atendidos: " + visitantesAtendidos);
        System.out.println(" - Tiempo espera promedio: " + tiempoEsperaPromedio + " segundos");
    }
}

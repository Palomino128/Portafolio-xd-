package parquetematico0.pkg5.strategy;

import parquetematico0.pkg5.interfaces.IVisitante;

/**
 * Estrategia de priorización para visitantes con discapacidad
 */
public class DiscapacidadPriorizacionStrategy implements PriorizacionStrategy {
    
    /**
     * Calcula la prioridad para visitantes con discapacidad
     * @param visitante El visitante a evaluar
     * @return 4 si el visitante tiene discapacidad, 0 en caso contrario
     */
    @Override
    public int calcularPrioridad(IVisitante visitante) {
        // Prioridad alta (4) para visitantes con discapacidad
        return "Discapacidad".equalsIgnoreCase(visitante.getTipoPase()) ? 4 : 0;
    }
}
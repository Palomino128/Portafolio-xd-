package parquetematico0.pkg5.estructuras;

import parquetematico0.pkg5.interfaces.ILista;

/**
 * Implementación de una lista enlazada genérica
 * @param <T> Tipo de elementos en la lista
 */
public class ListaEnlazada<T> implements ILista<T> {
    private Nodo<T> cabeza; // Cambiado de IColaPrioridad<T> a Nodo<T>
    private int tamano;
    
    // Clase interna para representar los nodos de la lista
    private static class Nodo<T> {
        T dato;
        Nodo<T> siguiente;
        
        Nodo(T dato) {
            this.dato = dato;
            this.siguiente = null;
        }
    }
    
    @Override
    public void agregar(T elemento) {
        insertar(tamano, elemento);
    }
    
    @Override
    public void insertar(int indice, T elemento) {
        if (indice < 0 || indice > tamano) {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
        
        Nodo<T> nuevoNodo = new Nodo<>(elemento);
        
        if (indice == 0) {
            nuevoNodo.siguiente = cabeza;
            cabeza = nuevoNodo;
        } else {
            Nodo<T> anterior = obtenerNodo(indice - 1);
            nuevoNodo.siguiente = anterior.siguiente;
            anterior.siguiente = nuevoNodo;
        }
        
        tamano++;
    }
    
    @Override
    public T obtener(int indice) {
        return obtenerNodo(indice).dato;
    }
    
    @Override
    public T eliminar(int indice) {
        if (indice < 0 || indice >= tamano) {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
        
        T datoEliminado;
        
        if (indice == 0) {
            datoEliminado = cabeza.dato;
            cabeza = cabeza.siguiente;
        } else {
            Nodo<T> anterior = obtenerNodo(indice - 1);
            datoEliminado = anterior.siguiente.dato;
            anterior.siguiente = anterior.siguiente.siguiente;
        }
        
        tamano--;
        return datoEliminado;
    }
    
    @Override
    public boolean contiene(T elemento) {
        Nodo<T> actual = cabeza;
        while (actual != null) {
            if (actual.dato.equals(elemento)) {
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }
    
    @Override
    public int tamano() {
        return tamano;
    }
    
    @Override
    public boolean estaVacia() {
        return tamano == 0;
    }
    
    private Nodo<T> obtenerNodo(int indice) {
        if (indice < 0 || indice >= tamano) {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
        
        Nodo<T> actual = cabeza;
        for (int i = 0; i < indice; i++) {
            actual = actual.siguiente;
        }
        return actual;
    }
}
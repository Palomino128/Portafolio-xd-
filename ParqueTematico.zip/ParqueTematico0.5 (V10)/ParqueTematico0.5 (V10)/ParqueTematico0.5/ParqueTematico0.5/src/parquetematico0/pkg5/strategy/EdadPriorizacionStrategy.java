
package parquetematico0.pkg5.strategy;

import parquetematico0.pkg5.interfaces.IVisitante;

public class EdadPriorizacionStrategy implements PriorizacionStrategy {
    @Override
    public int calcularPrioridad(IVisitante visitante) {
        // Prioridad más alta para niños pequeños y adultos mayores
        if (visitante.getEdad() < 8) return 2;
        if (visitante.getEdad() > 65) return 1;
        return 0;
    }
}
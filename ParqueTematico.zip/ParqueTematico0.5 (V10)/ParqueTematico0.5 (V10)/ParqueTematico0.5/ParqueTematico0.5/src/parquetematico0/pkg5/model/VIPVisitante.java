package parquetematico0.pkg5.model;

/**
 * Representa a un visitante con pase VIP.
 * Tiene prioridad alta y acceso a beneficios especiales.
 */
public class VIPVisitante extends Visitante {

    private boolean tieneAcompanante; // Solo usado si es menor de edad

    /**
     * Constructor principal.
     * @param nombre Nombre del visitante
     * @param edad Edad del visitante
     */
    public VIPVisitante(String nombre, int edad) {
        super(nombre, edad, "VIP");
        this.tieneAcompanante = edad >= 18; // Por defecto, los adultos no requieren
    }

    /**
     * Constructor alternativo si se quiere registrar explícitamente el acompañante.
     */
    public VIPVisitante(String nombre, int edad, boolean tieneAcompanante) {
        super(nombre, edad, "VIP");
        this.tieneAcompanante = tieneAcompanante;
    }

    public boolean isTieneAcompanante() {
        return tieneAcompanante;
    }

    public void setTieneAcompanante(boolean tieneAcompanante) {
        this.tieneAcompanante = tieneAcompanante;
    }

    // ================== Priorización ==================

    @Override
    public int getPrioridadBase() {
        return 3; // Prioridad alta
    }

    @Override
    public int getPrioridadAdicional() {
        if (edad < 18 && tieneAcompanante) {
            return 1; // Adolescente VIP con acompañante tiene bonificación
        }
        return 0;
    }

    // ================== Representación ==================

    @Override
    public String toString() {
        return String.format("Visitante VIP: %s | Edad: %d (%s) | ID: %s%s",
                nombre, edad, getCategoriaEdad(), id,
                (!tieneAcompanante && edad < 18) ? " | SIN ACOMPAÑANTE (NO PERMITIDO)" : "");
    }

    public String toCSV() {
        return String.format("%s,%d,%s,%b,%s",
                nombre, edad, tipoPase, tieneAcompanante, id);
    }

    public static String getCSVHeader() {
        return "Nombre,Edad,TipoPase,TieneAcompanante,ID";
    }
}

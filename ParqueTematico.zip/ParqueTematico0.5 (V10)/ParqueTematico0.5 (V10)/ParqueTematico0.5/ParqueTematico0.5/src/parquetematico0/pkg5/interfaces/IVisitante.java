// IVisitante.java
package parquetematico0.pkg5.interfaces;

/**
 * Interfaz para los visitantes del parque
 */
public interface IVisitante {
    String getNombre();
    int getEdad();
    String getTipoPase();
    long getTiempoLlegada();
    
    /**
     * Método para obtener la prioridad base del visitante
     * @return Prioridad calculada según su tipo
     */
    int getPrioridadBase();
    
    /**
     * Método para obtener prioridad adicional por características especiales
     * @return Prioridad adicional calculada
     */
    int getPrioridadAdicional();
}
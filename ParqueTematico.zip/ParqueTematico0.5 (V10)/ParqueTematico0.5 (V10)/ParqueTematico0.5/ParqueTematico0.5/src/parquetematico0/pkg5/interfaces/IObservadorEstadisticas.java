package parquetematico0.pkg5.interfaces;

public interface IObservadorEstadisticas {
    void actualizar(int visitantesAtendidos, double tiempoEsperaPromedio);
}
package parquetematico0.pkg5.estructuras;

import java.util.PriorityQueue;
import java.util.Comparator;

/**
 * Cola de prioridad genérica que ordena elementos según su prioridad (entero).
 * Mayor prioridad = primero en salir.
 */
public class ColaPrioridad<T> {

    /**
     * Clase interna que envuelve un dato con su prioridad.
     */
    private class ElementoPrioridad {
        T dato;
        int prioridad;

        public ElementoPrioridad(T dato, int prioridad) {
            this.dato = dato;
            this.prioridad = prioridad;
        }
    }

    // Cola interna con orden descendente (mayor prioridad sale primero)
    private PriorityQueue<ElementoPrioridad> cola;

    public ColaPrioridad() {
        cola = new PriorityQueue<>(Comparator.comparingInt((ElementoPrioridad ep) -> -ep.prioridad));
    }

    /**
     * Encola un elemento con prioridad.
     * @param dato El objeto a encolar.
     * @param prioridad Número entero. Cuanto mayor, más prioritario.
     */
    public void encolar(T dato, int prioridad) {
        cola.add(new ElementoPrioridad(dato, prioridad));
    }

    /**
     * Desencola y devuelve el siguiente elemento según prioridad.
     * @return El elemento con mayor prioridad o null si está vacía.
     */
    public T desencolar() {
        if (cola.isEmpty()) return null;
        return cola.poll().dato;
    }

    /**
     * Verifica si la cola está vacía.
     */
    public boolean estaVacia() {
        return cola.isEmpty();
    }

    /**
     * Retorna la cantidad de elementos en la cola.
     */
    public int tamano() {
        return cola.size();
    }

    /**
     * Muestra el primer elemento sin desencolar (opcional).
     */
    public T verPrimero() {
        ElementoPrioridad primero = cola.peek();
        return primero != null ? primero.dato : null;
    }
}

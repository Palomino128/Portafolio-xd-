// IColaPrioridad.java
package parquetematico0.pkg5.interfaces;

/**
 * Interfaz para una cola con prioridad genérica
 * @param <T> Tipo de elementos en la cola
 */
public interface IColaPrioridad<T> {
    void encolar(T elemento, int prioridad);
    T desencolar();
    T frente();
    boolean estaVacia();
    int tamano();
}


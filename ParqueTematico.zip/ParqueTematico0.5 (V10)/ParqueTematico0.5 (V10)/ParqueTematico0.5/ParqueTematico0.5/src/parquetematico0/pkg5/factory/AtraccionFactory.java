package parquetematico0.pkg5.factory;

import parquetematico0.pkg5.model.Atraccion;

public class AtraccionFactory {
    public static Atraccion crearAtraccion(String nombre, String tipo) {
        switch (tipo.toLowerCase()) {
            case "montania rusa":
                return new Atraccion(nombre, 20, 120, 68.0, 121.0, 0.0); // Añadido 0.0 como último parámetro
            case "rueda gigante":
                return new Atraccion(nombre, 30, 360, 8.0, 20.0, 35.0);
            case "laguna":
                return new Atraccion(nombre, 15, 180, 12.0, 25.0, 38.0);
            default:
                return new Atraccion(nombre, 15, 150, 10.0, 20.0, 30.0);
        }
    }
}
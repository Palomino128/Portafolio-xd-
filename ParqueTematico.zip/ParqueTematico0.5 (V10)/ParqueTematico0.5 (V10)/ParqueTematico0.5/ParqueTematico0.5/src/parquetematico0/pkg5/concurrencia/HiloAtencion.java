package parquetematico0.pkg5.concurrencia;

import parquetematico0.pkg5.model.Atraccion;

public class HiloAtencion extends Thread {
    private final Atraccion atraccion;
    private final int intervalo;
    private final int minimoCola; // <- Nuevo: mínimo de personas en cola para atender
    private boolean activo;

    public HiloAtencion(Atraccion atraccion, int intervalo, int minimoCola) {
        this.atraccion = atraccion;
        this.intervalo = intervalo;
        this.minimoCola = minimoCola;
        this.activo = true;
    }

    @Override
    public void run() {
        while (activo) {
            try {
                Thread.sleep(intervalo);

                // Solo atiende si hay suficientes personas en la cola
                if (atraccion.getTamanioCola() >= minimoCola) {
                    for (int i = 0; i < atraccion.getCapacidad(); i++) {
                        atraccion.atenderVisitante();
                    }
                }

            } catch (InterruptedException e) {
                System.out.println("Hilo interrumpido: " + e.getMessage());
            }
        }
    }

    public void detener() {
        activo = false;
    }
}

CREATE DATABASE detector_plagio;

USE detector_plagio;

CREATE TABLE alumnos 
(
    id INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(100),
    apellido VARCHAR(100),
    texto TEXT,
    es_plagio BIT
);
CREATE LOGIN TestUser WITH PASSWORD = 'Password123';
USE detector_plagio;
CREATE USER TestUser FOR LOGIN TestUser;
ALTER ROLE db_owner ADD MEMBER TestUser;
